const express = require('express');
var redis = require('redis');
const kafkaCuns = require('./controller/KafkaCunsumer');
var server = require('http').createServer(app);

const app = express();
const port = 3001

const redisClient = redis.createClient();
(async () => {

  redisClient.on('error', (err) => console.log('Redis Client Error', err));

  await redisClient.connect();

  await redisClient.set('key', 'value');
  const value = await redisClient.get('key');
})();

//--------------ejs---------------------
app.set('view engine', 'ejs');
app.use(express.static("public"));
app.get('/', (req, res) => res.render('BigML'));
// app.get('/DashboardController.js', (req, res) => res.sendFile('Controller/DashboardController.js', { root: __dirname }));
// app.get('/Dashboard.css', (req, res) => res.sendFile('Views/Dashboard.css', { root: __dirname }));


server.listen(port, () => console.log(`System B app listening at http://localhost:${port}`));